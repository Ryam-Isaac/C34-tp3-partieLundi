public class Position
{

    private int ligne ; // de 0 à 7 voir schéma
    private int colonne; // de 0 à 7


    public Position(int ligne, int colonne) {
        setColonne(ligne);
        setLigne(colonne);
    }


    public int getLigne ()
    {
        return ligne;
    }

    public int getColonne ()
    {
        return colonne;
    }

    public void setLigne (int ligne)
    {
        if (ligne >= 0 && ligne <= 7) {
            this.ligne = ligne;
        } else {
            this.ligne = 0;
        }
    }

    public void setColonne ( int colonne )
    {

        if (colonne >= 0 && colonne <= 7) {
            this.colonne = colonne;
        } else {
            this.colonne = 0;
        }
    }

}
