public class Pion extends Piece {

    public Pion(String nom, String couleur) {
        super(nom, couleur);
    }

    public boolean estValide(Position depart, Position arrivee) {

        if (depart.getLigne() == arrivee.getLigne() && depart.getColonne() == arrivee.getColonne()) {
            return true;
        }

        int deltaX = arrivee.getColonne() - depart.getColonne();
        int deltaY = arrivee.getLigne() - depart.getLigne();

        if (getCouleur().equals("blanc")) {
            if (deltaX == 0 && (deltaY == -1 || (depart.getLigne() == 6 && deltaY == -2))) {
                return true;
            }
            if (Math.abs(deltaX) == 1 && deltaY == -1) {
                return true;
            }
        } else if (getCouleur().equals("noir")) {
            if (deltaX == 0 && (deltaY == 1 || (depart.getLigne() == 1 && deltaY == 2))) {
                return true;
            }
            if (Math.abs(deltaX) == 1 && deltaY == 1) {
                return true;
            }
        }

        return false;
    }
}
