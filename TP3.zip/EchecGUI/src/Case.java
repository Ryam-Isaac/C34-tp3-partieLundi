import java.util.Objects;

public class Case {

    private Piece piece;

    public Case() {
        this.piece = null;
    }

    public Case(Piece piece) {
        this.piece = piece;
    }

    public Piece getPiece() {
        return this.piece;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }


    public boolean caseOccupee() {
        if (this.piece != null) {
            return true;
        } else {
            return false;
        }
    }


    public boolean caseOccupeeParCouleur(String couleur) {
        if (this.piece != null) {
            if (Objects.equals(this.piece.getCouleur(), couleur)) {
                return true;
            }
        }
        return false;
    }

    public Piece enleverPiece() {
        Piece pieceTemporaire = this.piece;
        this.piece = null;
        return pieceTemporaire;
    }

}
