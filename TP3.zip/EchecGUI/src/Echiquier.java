public class Echiquier implements MethodesEchiquier {

    public Case[][] getLocation() {
        return location;
    }

    public void setLocation(Case[][] location) {
        this.location = location;
    }

    private Case[][] location;

    public Echiquier() {
        location = new Case[8][8];

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                location[i][j] = new Case();
            }
        }
    }

    public Case getCase(int i, int j) {
        if (i >= 0 && i < 8 && j >= 0 && j < 8) {
            return  location[i][j];
        } else {
            return null;
        }
    }


    @Override
    public void debuter() {
        for (int j = 0; j < 8; j++) {
            location[1][j].setPiece(new Pion("p" + (j + 1), "noir"));
        }

        for (int j = 0; j < 8; j++) {
            location[6][j].setPiece(new Pion("p" + (j + 1), "blanc"));
        }


        // Pièces noires (rangée 0)
        location[0][0].setPiece(new Tour("t1", "noir"));
        location[0][1].setPiece(new Cavalier("c1", "noir"));
        location[0][2].setPiece(new Fou("f1", "noir"));
        location[0][3].setPiece(new Reine("r", "noir"));
        location[0][4].setPiece(new Roi("k", "noir"));
        location[0][5].setPiece(new Fou("f2", "noir"));
        location[0][6].setPiece(new Cavalier("c2", "noir"));
        location[0][7].setPiece(new Tour("t2", "noir"));




        location[7][0].setPiece(new Tour("t1", "blanc"));
        location[7][1].setPiece(new Cavalier("c1", "blanc"));
        location[7][2].setPiece(new Fou("f1", "blanc"));
        location[7][3].setPiece(new Reine("r", "blanc"));
        location[7][4].setPiece(new Roi("k", "blanc"));
        location[7][5].setPiece(new Fou("f2", "blanc"));
        location[7][6].setPiece(new Cavalier("c2", "blanc"));
        location[7][7].setPiece(new Tour("t2","blanc"));
    }


    @Override
    public boolean cheminPossible(Position depart, Position arrivee) {
        if (depart.equals(arrivee)) {
            return true;
        }

        Piece piece = getCase(depart.getLigne(), depart.getColonne()).getPiece();
        if (piece == null) {
            return false;
        }

        Piece pieceDest = getCase(arrivee.getLigne(), arrivee.getColonne()).getPiece();
        if (pieceDest != null && pieceDest.getCouleur().equals(piece.getCouleur())) {
            return false;
        }

        if (piece.getNom().equals("Cavalier")) {
            return piece.estValide(depart, arrivee);
        }

        int differenceLigne = arrivee.getLigne() - depart.getLigne();
        int directionLigne;
        if (differenceLigne > 0) {
            directionLigne = 1;
        } else if (differenceLigne < 0) {
            directionLigne = -1;
        } else {
            directionLigne = 0;
        }

        int differenceColonne = arrivee.getColonne() - depart.getColonne();
        int directionColonne;
        if (differenceColonne > 0) {
            directionColonne = 1;
        } else if (differenceColonne < 0) {
            directionColonne = -1;
        } else {
            directionColonne = 0;
        }

        int ligneActuelle = depart.getLigne() + directionLigne;
        int colonneActuelle = depart.getColonne() + directionColonne;

        while (ligneActuelle != arrivee.getLigne() || colonneActuelle != arrivee.getColonne()) {
            if (getCase(ligneActuelle, colonneActuelle).caseOccupee()) {
                return false;
            }
            ligneActuelle += directionLigne;
            colonneActuelle += directionColonne;
        }

        if (piece.getNom().equals("Pion") && directionColonne == 0 && pieceDest != null) {
            return false;
        }

        return piece.estValide(depart, arrivee);
    }




    @Override
    public boolean captureParUnPionPossible(Position depart, Position arrivee) {
        Piece piece = getCase(depart.getLigne(), depart.getColonne()).getPiece();
        if (piece == null || !piece.getNom().equals("Pion")) {
            return false;
        }

        Piece pieceCible = getCase(arrivee.getLigne(), arrivee.getColonne()).getPiece();
        if (pieceCible == null || pieceCible.getCouleur().equals(piece.getCouleur())) {
            return false; // pas de pièce ennemie
        }

        int direction;
        if (piece.getCouleur().equals("blanc")) {
            direction = -1;
        } else {
            direction = 1;
        }

        int diffLigne = arrivee.getLigne() - depart.getLigne();
        int diffCol = Math.abs(arrivee.getColonne() - depart.getColonne());

        if (diffLigne == direction && diffCol == 1) {
            return true;
        } else {
            return false;
        }
    }


}
