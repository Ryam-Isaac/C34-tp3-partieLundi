import org.junit.Test;
import static org.junit.Assert.*;

public class PieceTest {

    @Test
    public void testRoi() {
        Piece roi = new Roi("k", "blanc");
        assertTrue(roi.estValide(new Position(4, 4), new Position(4, 4)));
        assertTrue(roi.estValide(new Position(4, 4), new Position(5, 4)));
    }

    @Test
    public void testReine() {
        Piece reine = new Reine("r", "noir");
        assertTrue(reine.estValide(new Position(0, 0), new Position(7, 0)));
        assertTrue(reine.estValide(new Position(0, 0), new Position(0, 7)));
    }

    @Test
    public void testCavalier() {
        Piece cavalier1 = new Cavalier("c1", "blanc");
        assertTrue(cavalier1.estValide(new Position(7, 1), new Position(5, 2)));

        Piece cavalier2 = new Cavalier("c2", "noir");
        assertTrue(cavalier2.estValide(new Position(0, 1), new Position(2, 2)));
    }

    @Test
    public void testFou() {
        Piece fou1 = new Fou("f1", "blanc");
        assertTrue(fou1.estValide(new Position(7, 2), new Position(4, 5)));

        Piece fou2 = new Fou("f2", "noir");
        assertTrue(fou2.estValide(new Position(0, 5), new Position(3, 2)));
    }

    @Test
    public void testTour() {
        Piece tour1 = new Tour("t1", "blanc");
        assertTrue(tour1.estValide(new Position(7, 0), new Position(7, 7)));

        Piece tour2 = new Tour("t2", "noir");
        assertTrue(tour2.estValide(new Position(0, 0), new Position(6, 0)));

    }

    @Test
    public void testPion() {
        Piece pion1 = new Pion("p1", "blanc");
        assertTrue(pion1.estValide(new Position(6, 0), new Position(5, 0)));

        Piece pion2 = new Pion("p2", "blanc");
        assertTrue(pion2.estValide(new Position(6, 1), new Position(4, 1)));
    }
}
