public class Cavalier extends Piece {

    public Cavalier(String nom, String couleur) {
        super(nom, couleur);
    }

    @Override
    public boolean estValide(Position depart, Position arrivee) {
        if (depart.getLigne() == arrivee.getLigne() && depart.getColonne() == arrivee.getColonne()) {
            return true;
        }

        int deltaX = Math.abs(arrivee.getColonne() - depart.getColonne());
        int deltaY = Math.abs(arrivee.getLigne() - depart.getLigne());

        return (deltaX == 2 && deltaY == 1) || (deltaX == 1 && deltaY == 2);
    }
}
