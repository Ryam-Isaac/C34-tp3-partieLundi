public class Reine extends Piece {

    public Reine(String nom, String couleur) {
        super(nom, couleur);
    }


    @Override
    public boolean estValide(Position depart, Position arrivee) {
        if (depart.getLigne() == arrivee.getLigne() && depart.getColonne() == arrivee.getColonne()) {
            return true;
        }

        int deltaX = Math.abs(arrivee.getColonne() - depart.getColonne());
        int deltaY = Math.abs(arrivee.getLigne() - depart.getLigne());

        if (depart.getLigne() == arrivee.getLigne() || depart.getColonne() == arrivee.getColonne()) {
            return true;
        }

        if (deltaX == deltaY) {
            return true;
        }

        return false;
    }

}
