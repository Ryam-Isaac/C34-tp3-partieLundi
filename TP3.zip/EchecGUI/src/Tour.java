public class Tour extends Piece {

    public Tour(String nom, String couleur) {
        super(nom, couleur);
    }


    @Override
    public boolean estValide(Position depart, Position arrivee) {

        if (depart.getLigne() == arrivee.getLigne() && depart.getColonne() == arrivee.getColonne()) {
            return true;

        } else if (depart.getLigne() == arrivee.getLigne() || depart.getColonne() == arrivee.getColonne()) {
            return true;
        } else {
            return false;
        }
    }
}

